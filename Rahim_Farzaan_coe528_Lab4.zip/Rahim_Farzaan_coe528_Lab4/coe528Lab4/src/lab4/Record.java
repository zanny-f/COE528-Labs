/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4;
import java.io.*;

/**
 *
 * @author farza
 */
public class Record {
    

//Name of the associated file
private String filename;
  
//public instance initialized when loading the class
//final so that we can't change it once initialized
private static final Record instance = new Record("record.txt");
  
//Constructor should be private in singleton design pattern
//so that no one can call it from outside
private Record(String n)
{
filename = n; //initializing the filename
}
  
//method to return the instance
//(in our case, it passes the instace to the main() method)
public static Record getInstance()
{
return instance;
}
  
// Effects: Reads and prints the contents of the associated file to the standard output.
public void read()
{
try
{
// Write the code here
File file = new File(filename);
//BufferedReader object to read the data from the file
BufferedReader br = new BufferedReader(new FileReader(file));
  
String st; //to store the line one by one

//read the data till the last line
while((st = br.readLine()) != null)
{
System.out.println(st); //print the data of current line
}
}
catch(IOException e)
{   
System.out.println("An error occurred.");
//e.printStackTrace();
}
}
  
// Effects: Appends the specified message, msg, to the associated file.
public void write(String msg)
{
try
{
// Write the code here

//FileWriter object to write the data to the file
/*true indicates that we have to append the data to the file,
without deleting the data that already exists in the file*/
FileWriter fw = new FileWriter(filename, true);
for (int i = 0; i < msg.length(); i++)
{
fw.write(msg.charAt(i)); //writing the data character by character
}
fw.close(); //flush the stream and close the object
}
catch(IOException e)
{
System.out.println("An error occurred.");
//e.printStackTrace();
}
}
  
//driver method of the program
public static void main(String[] args)
{
// Fill the blank below that obtains the sole instance of the Record class.
// (You should not invoke the Record constructor here.)
Record r = getInstance(); //get the instance of the class Record
  
// Do not modify the code below
r.write("Hello-1\n");
r.write("Hello-2\n");
System.out.println("Currently the file record.txt contains the following lines:");
r.read();
}
}

