/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author farza
 */
public class FlightTest {
    
    public FlightTest() {
    }
    
    int flightNumber=123;
    String orgin= "Toronto"; //-
    String destination= "Karachi";//doesnt matter
    String departureTime ="12:40";//-
    int capacity =45;//-
    int numberOfSeatsLeft=40;//-
    double originalPrice= 120.0;//-
    Flight f =new Flight(flightNumber, capacity, originalPrice, orgin, departureTime, destination);
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of setorgin method, of class Flight.
     */
    
    @Test
    public void testConstrutor(){
        System.out.println("Test contructor");
        Flight instance = new Flight(flightNumber, capacity, originalPrice, orgin, departureTime, destination);
    }
    
    @Test (expected= IllegalArgumentException.class)
    public void testInvalidConstructor(){
        System.out.println("Test invalid contructor");
        Flight instance = new Flight(flightNumber, capacity, originalPrice, orgin, departureTime, orgin);
    }
    @Test
    public void testSetorgin() {
        System.out.println("setorgin");
        String orgin = "Toronto";
        Flight instance = new Flight(flightNumber, capacity, originalPrice, orgin, departureTime, destination);
        instance.setorgin(orgin);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of getorgin method, of class Flight.
     */
    @Test
    public void testGetorgin() {
        System.out.println("getorgin");
        Flight instance = new Flight(flightNumber, capacity, originalPrice, orgin, departureTime, destination);
        String expResult = "Toronto";
        String result = instance.getorgin();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of setdestination method, of class Flight.
     */
    @Test
    public void testSetdestination() {
        System.out.println("setdestination");
        String destination = "Karachi";
        Flight instance = new Flight(flightNumber, capacity, originalPrice, orgin, departureTime, destination);
        instance.setdestination(destination);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of getdestination method, of class Flight.
     */
    @Test
    public void testGetdestination() {
        System.out.println("getdestination");
        Flight instance = new Flight(flightNumber, capacity, originalPrice, orgin, departureTime, destination);
        String expResult = "Karachi";
        String result = instance.getdestination();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of setflightNumber method, of class Flight.
     */
    @Test
    public void testSetflightNumber() {
        System.out.println("setflightNumber");
        int flightNumber = 123;
        Flight instance = new Flight(flightNumber, capacity, originalPrice, orgin, departureTime, destination);
        instance.setflightNumber(flightNumber);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of getflightNumber method, of class Flight.
     */
    @Test
    public void testGetflightNumber() {
        System.out.println("getflightNumber");
        Flight instance = new Flight(flightNumber, capacity, originalPrice, orgin, departureTime, destination);
        int expResult = 123;
        int result = instance.getflightNumber();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of setdepartureTime method, of class Flight.
     */
    @Test
    public void testSetdepartureTime() {
        System.out.println("setdepartureTime");
        String departureTime = "12:40";
        Flight instance = new Flight(flightNumber, capacity, originalPrice, orgin, departureTime, destination);
        instance.setdepartureTime(departureTime);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of getdepartureTime method, of class Flight.
     */
    @Test
    public void testGetdepartureTime() {
        System.out.println("getdepartureTime");
        Flight instance = new Flight(flightNumber, capacity, originalPrice, orgin, departureTime, destination);
        String expResult = "12:40";
        String result = instance.getdepartureTime();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    
    }

    /**
     * Test of setcapacity method, of class Flight.
     */
    @Test
    public void testSetcapacity() {
        System.out.println("setcapacity");
        int capacity = 45;
        Flight instance = new Flight(flightNumber, capacity, originalPrice, orgin, departureTime, destination);
        instance.setcapacity(capacity);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of getcapacity method, of class Flight.
     */
    @Test
    public void testGetcapacity() {
        System.out.println("getcapacity");
        Flight instance = new Flight(flightNumber, capacity, originalPrice, orgin, departureTime, destination);
        int expResult = 45;
        int result = instance.getcapacity();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of setnumberOfSeatsLeft method, of class Flight.
     */
    @Test
    public void testSetnumberOfSeatsLeft() {
        System.out.println("setnumberOfSeatsLeft");
        int numberOfSeatsLeft = 45;
        Flight instance = new Flight(flightNumber, capacity, originalPrice, orgin, departureTime, destination);
        instance.setnumberOfSeatsLeft(numberOfSeatsLeft);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of getnumberOfSeatsLeft method, of class Flight.
     */
    @Test
    public void testGetnumberOfSeatsLeft() {
        System.out.println("getnumberOfSeatsLeft");
        Flight instance = new Flight(flightNumber, capacity-1, originalPrice, orgin, departureTime, destination);
        int expResult = 44;
        int result = instance.getnumberOfSeatsLeft();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
   
    }

    /**
     * Test of setoriginaPrice method, of class Flight.
     */
    @Test
    public void testSetoriginaPrice() {
        System.out.println("setoriginaPrice");
        double originalPrice = 120.0;
        Flight instance = new Flight(flightNumber, capacity, originalPrice, orgin, departureTime, destination);
        instance.setoriginaPrice(originalPrice);
        // TODO review the generated test code and remove the default call to fail.
    
    }

    /**
     * Test of getoriginalPrice method, of class Flight.
     */
    @Test
    public void testGetoriginalPrice() {
        System.out.println("getoriginalPrice");
        Flight instance = new Flight(flightNumber, capacity, originalPrice, orgin, departureTime, destination);
        double expResult = 120.0;
        double result = instance.getoriginalPrice();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
     
    }

    /**
     * Test of bookASeat method, of class Flight.
     */
    @Test
    public void testBookASeat() {
        System.out.println("bookASeat");
        Flight instance = new Flight(flightNumber, capacity, originalPrice, orgin, departureTime, destination);
        boolean expResult = true;
        boolean result = instance.bookASeat();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of toString method, of class Flight.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Flight instance = new Flight(flightNumber, capacity, originalPrice, orgin, departureTime, destination);
        String expResult = "Flight 123, Toronto to Karachi, 12:40, Original Price: 120.0$.";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
       
    }
    
}
