/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;

/**
 *
 * @author farza
 */
//CHECK CAPACITY GETTER FOR SEAT LINE 70
//CHECK NUMBER OF SEATS LEFT SEATS AND CAPACITY DECREEMENT
public class Flight {
    //instance variables
    int flightNumber;//-
    String orgin; //-
    String destination;//doesnt matter
    String departureTime;//-
    int capacity;//-
    int numberOfSeatsLeft;//-
    double originalPrice;//-
    
    public Flight (int flightNumber, int capacity, double originalPrice, String orgin, String departureTime, String destination){
        //Convert instance to local
       this.flightNumber=flightNumber;
       this.capacity=capacity;
        numberOfSeatsLeft=capacity;
        this.originalPrice=originalPrice; 
        this.orgin=orgin;
        this.departureTime=departureTime;
        this.destination=destination;
        
        if (orgin.equals(destination)){
            throw new IllegalArgumentException("Error: Orgin and destination cant be the same!");
          
        }
}
    //Setter method for orgin
    public void setorgin (String orgin){
        //check if orgin equals to destination
   this.orgin=orgin;
    }
    //get orgin
    public String getorgin(){
        return orgin;
    }
    //set destination
    public void setdestination(String destination){
        this.destination=destination;
    }
    //get destination
    public String getdestination(){
        return destination;
    }
    //set flight number
    public void setflightNumber(int flightNumber){
        this.flightNumber=flightNumber;
    }
    //get flight number
    public int getflightNumber(){
        return flightNumber;
    }
    //set departure time
    public void setdepartureTime(String departureTime){
        this.departureTime=departureTime;
    }
    //get departure time
    public String getdepartureTime(){
        return departureTime;
    }
    //set capacity
    public void setcapacity(int capacity){
        this.capacity=capacity;
    }
    //get capacity
    public int getcapacity(){
        return capacity;
    }
    //set number of seats
    public void setnumberOfSeatsLeft(int numberOfSeatsLeft){
        if (capacity < numberOfSeatsLeft && capacity <=1){
            throw new IllegalArgumentException("Error: Number of seats left are less then the capacity!!");
        }
        //Set orgin variable (do you need this??)
        else{
        this.numberOfSeatsLeft=numberOfSeatsLeft;
    }
    }
   
    //get number of seats
    public int getnumberOfSeatsLeft(){
        return numberOfSeatsLeft;
    }
    //set original price
    public void setoriginaPrice(double originalPrice){
        this.originalPrice=originalPrice;
    }
    //get original price
    public double getoriginalPrice(){
        return originalPrice;
    }
    //book a seat method
    public boolean bookASeat(){
        if (numberOfSeatsLeft > 0){
          --numberOfSeatsLeft;
          return true;
        }
        else{
            return false;
        }
    }
    @Override
    public String toString()
    {
        return("Flight " + flightNumber + ", " +orgin + " to " + destination +", " + departureTime + ", Original Price: " + originalPrice +"$.");
    } 
}

