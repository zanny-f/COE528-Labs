/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;

/**
 *
 * @author farza
 */

public class NonMember extends Passenger{    

    public NonMember(String name, int age) {
        super(name, age);
    }

    @Override
    //Apply discount
    public double applyDiscount(double p) {
        //age check for passenger discount
        if(age>65){
            return p*0.9;
        }
        else {
            return p;
        }
    }   
}
