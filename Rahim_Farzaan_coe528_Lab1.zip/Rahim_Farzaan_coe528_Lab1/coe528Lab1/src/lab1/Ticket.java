/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;

/**
 *
 * @author farza
 */

public class Ticket{
Flight flight;//-
Passenger passenger;//-
double price;//-
int number;   //exclusively for ticket number
static int numberTicketUno = 1;
static int numberTicketDuo = 2;

    public Ticket(Flight flight, Passenger p, double price){
    //initializing variables
    this.flight=flight;
    this.passenger=p;
    this.price=price;
}
//get flight
    public Flight getflight(){
        return flight;
    }
    //set flight
    public void setflight(Flight flight){
        this.flight=flight;
    }
     //set passengers
    public void setpassenger(Passenger p){
        this.passenger=p;
    }
    //get passenger
    public Passenger getpassenger(){
        return passenger;
    }
    //set price
    public void setprice(double price){
        this.price=price;
    }
    //get price
    public double getprice(){
        return price;
    }
    @Override
    public String toString()
    {
        return("Passenger Name: " + passenger.name + ", Ticket Price: " + price);
    } 
}
