/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;

/**
 *
 * @author farza
 */
public class Member extends Passenger {
    //instance varibles
    int yearsOfMembership;

    public Member(String name, int age, int yearsOfMembership) {
        super(name, age);
        this.yearsOfMembership=yearsOfMembership;
    }

    
    //override method for discount
    @Override
    public double applyDiscount(double dis) {
        //apply discount
        if (yearsOfMembership>5){
            return dis*0.5;
        }
        if(yearsOfMembership>1&&yearsOfMembership<=5){
            return dis*0.9;
        }
        else {
            return dis;
        }
    }
    
}   
