/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;

/**
 *
 * @author farza
 */
//import Scanner
import java.util.Scanner;
import java.util.ArrayList;
public class Manager {
    ArrayList <Flight> flights = new ArrayList <>();
    ArrayList <Ticket> tickets = new ArrayList <>();
    //Flight [] flights;
    //TicketClass [] tickets;
    
    //create flight method to populate the flights array
    public void createFlights(){
        //Scanner input
        System.out.println("Enter the ammount of Fligths needed: ");
        Scanner scan = new Scanner (System.in);
        int i =scan.nextInt();
        //for loop to create the flights needed
        for (int j=0; j<i; j++){
            System.out.println("Enter a Flight Number: ");
            int fn=scan.nextInt();
            System.out.println("Enter capacity limit: ");
            int cap=scan.nextInt();
            System.out.println("Enter opriginal price of the flight: ");
            double op=scan.nextDouble();
            System.out.println("Enter an Orgin: ");
            String or=scan.next();
            System.out.println("Enter departure time: ");
            String dt=scan.next();
            System.out.println("Enter a destination for the flight: ");
            String des=scan.next();
            
            //flights=new ArrayList <>(i);//print flight array at the end
            //
            flights.add(new Flight(fn,cap,op,or,dt,des));
        }        
    }
    //display avalible flights
    public void displayAvalibleFlights (String orgin, String destination){
        for(int j=0; j<flights.size(); j++){
            if (orgin.equals(flights.get(j).orgin)&&(destination.equals(flights.get(j).destination))){
                //System.out.println (flights.get(j).destination, flights.get(j).orgin, flights.get(j).numberOfSeatsLeft);
                if (flights.get(j).numberOfSeatsLeft > 0){
                    System.out.println(flights.get(j).toString()); //toString method coverst ojects to String
            }   
            }
        }
    }
     public Flight getFlight(int flightNumber) {
        
        Flight c = null;                // If there is no flight number that matches, this method returns null.
        
        for(int i = 0; i < flights.size(); i++) {
            
            if(flights.get(i).getflightNumber() == flightNumber) {
                
                return flights.get(i);
            }
            
        }
         
      return c;
     }
    //return flight for the specific flight number
   /* public Flight getFlight(int flightNumber){
        for (int j=0; j<flights.size(); j++){
            if (flightNumber==flights.get(j).flightNumber){
            return flights.get(j);
        }
    }
        return null ;
    }
*/
 
    //book a seat method calling and checking
    public void bookSeat(int flightNumber, Passenger p){
        for (Flight f:flights){
      //  Flight f=getFlight(flightNumber);
        double x;
        if(f.bookASeat()==true){
            x= p.applyDiscount(f.getoriginalPrice());
            tickets.add(new Ticket(f,p,x));
            System.out.println("Ticket: "+ tickets.toString());
        }
    }
    }      
    
    
    
    //MAIN METHOD CALLING ALL CLASSES AND METHODS NEEDED
    public static void main(String args[]){
        Manager m = new Manager();
        Flight f;
        Passenger P;
        Scanner scan1 = new Scanner(System.in);
        Scanner scan2 = new Scanner(System.in);
        String input, destination, origin, name;
        int Fn, age, years;
        boolean flag = false;

        while (flag != true) {
            System.out.println("Enter a if you would like to create a flight (creatFlight method)");
            System.out.println("Enter b if you would like to display all flights (displayAvailableFlights method)");
            System.out.println("Enter c if you would like to get information on a flight (getFlight method)");
            System.out.println("Enter d if you would like to book a seat (bookSeat method)");
            System.out.println("Enter exit if you would like to exit the program");
            input = scan1.nextLine();
            switch (input) {
                case "a":
                    m.createFlights();
                    break;
                case "b":
                    System.out.println("Enter flight Origin");
                    origin = scan1.nextLine();
                    System.out.println("Enter flight Destination");
                    destination = scan1.nextLine();
                    m.displayAvalibleFlights(origin, destination);
                    break;
                case "c":
                    System.out.println("Enter Flight Number");
                    Fn = scan2.nextInt();
                    f = m.getFlight(Fn);
                    if (f == null) {
                        System.out.println("Flight " + Fn + " does not exist");
                    } else {
                        System.out.println("Info for Flight " + Fn + ":");
                        System.out.println(f);
                    }
                    break;
                case "d":
                    System.out.println("If passenger is non memeber enter n, if passenger is a member enter m");
                    input = scan1.nextLine();
                    System.out.println("Enter passengers age");
                    age = scan2.nextInt();
                    System.out.println("Enter passengers name");
                    name = scan1.nextLine();
                    System.out.println("Enter Flight Number");
                    Fn = scan2.nextInt();

                    if (input.equals("n") == true) {
                        P = new NonMember(name, age);
                        m.bookSeat(Fn, P);
                    } else if (input.equals("m") == true) {
                        System.out.println("For how many years has the passenger been a member");
                        years = scan2.nextInt();
                        P = new Member(name, age, years); ///YERAS?/??
                        m.bookSeat(Fn, P);

                    }
                    break;
                case "exit":
                    flag = true;
                    System.out.println("You have exited the program.");
                    break;
                default:
                    System.out.println("You entered an invalid option");
                    break;

            }
       
    }
    }
}
