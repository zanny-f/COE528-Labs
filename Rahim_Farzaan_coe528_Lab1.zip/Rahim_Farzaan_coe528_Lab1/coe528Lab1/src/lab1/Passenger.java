/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;

/**
 *
 * @author farza
 */
//Check Override method for this
public abstract class Passenger {
    //Instance Variables
    String name;
    int age;
    
    public Passenger(String name, int age){
    //initialize instant variables
    this.name=name;
    this.age=age;
}
    //set method for name
    public void setname(String name){
        this.name=name;
    }
    //get method for name
    public String getname(){
        return name;
    }
    //set method for age
    public void setage(int age){
        this.age=age;
    }
    //get method for age
    public int getage(){
        return age;
    }
    //abstract method for discount
    public abstract double applyDiscount(double dis);
}
