/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package lab2;
import java.util.ArrayList;
/**
 *
 * @author farza
 */
public class ProceduralAbstraction {

    
    public static int reverseFactorial(int x){
        int result=1;
        for (int i=1; i<x; i++){
            result =i*result;
            if (result>=x){
                return i;
            }
        }
    return result;
    }
    
        public static boolean isMatrixNice(int[][] arr) {

        int diagSum = 0;
        int inDiagSum = 0;
        int colmSum = 0;
        int rowSum = 0;
        //int sum = 0;
        ArrayList<Integer> sumOfArray = new ArrayList<Integer>(); 
        
        //Check if the matrix is empty
        if (arr == null || arr.length == 0){ 
            return false;
        }

        //Check if the matrix is a square matrix
        for (int x = 0; x < arr.length; x++){
            if (arr[x].length != arr.length){ 
                System.out.println("This matrix is not a square matrix.");
                return false;
            }
        }
        
        //Find the sum of each row
        for (int x = 0; x < arr.length; x++){
                    rowSum =0;
            for (int i = 0; i < arr[x].length; i++) {
                rowSum += arr[x][i];
            }
            sumOfArray.add(rowSum);
        }
        
        // Finding the sum of each column
        for (int x = 0; x < arr.length; x++){
                colmSum =0;
            for (int i = 0; i < arr[x].length; i++){
                colmSum += arr[x][i]; 
            }
            sumOfArray.add(colmSum);
        }
        
        for (int x = 0; x < arr.length; x++){
            diagSum += arr[x][x];           
        }

        for (int x = arr.length-1 ; x >= 0; x--) {
            inDiagSum += arr[x][x];   
        }
        sumOfArray.add(diagSum);
        sumOfArray.add(inDiagSum);
        
     for (int temp : sumOfArray){
        if (!(temp==sumOfArray.get(0))){
           System.out.println("This matrix is not a nice matrix.");
            return false;
        }
    }
        System.out.println("The matrix is a nice matrix. The sum is "+rowSum);
        return true;
    }
}
