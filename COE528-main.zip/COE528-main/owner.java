/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe528_project;

import java.util.ArrayList;

/**
 *
 * @author Rayyan Bilal
 */
public class owner {
    private String password;
    private String username;
    ArrayList<Customer> CustomerList = new ArrayList<Customer>();

    private void addCustomer(String username, String password) {
        //CustomerList.add(Customer.username, Customer.password);
        //In our class diagram we had addCustomer as having Customer as a return type
        //I think it should be void 
        //Needs more thought 
    }

}
