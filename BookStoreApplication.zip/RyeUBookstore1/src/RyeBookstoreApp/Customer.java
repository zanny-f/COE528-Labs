package RyeBookstoreApp;

public class Customer {               //Initializing variables types above for Customer Info
    private double point;
    private String cusname;
    private String cuspass;
    private String Status;
    private State state;

public Customer (){              //Assigning values and attributes to each variable for Customer Info
    this.point = 0;
    this.cusname = "";
    this.cuspass = "";
}

public Customer(String cusname, String cuspass, double point){ //Connects inital and local variables for Customer Info
    this.point = point;
    this.cusname = cusname;
    this.cuspass = cuspass;
      
}
//getter method for obtaining the points and returning it back
public double getPoint(){
    return point;
}
//setter method for simply setting the points
public void setPoint(double point){
    this.point = point;
}
//getter method for obtaining the customer's username
public String getCusname(){ 
    return cusname;
}
//setter method for simply setting a customer's username
public void setCusname(String cusname){
    this.cusname = cusname;
}
//getter method for obtaining the customer's password
public String getCuspass(){
    return cuspass;
}
//setter method for simply setting a customer's password
public void setCuspass(String cuspass){
    this.cuspass = cuspass;
}
 public void setState() {
         if (point < 1000) {
            state =new Silver();
        }
        
        else if (point >= 1000) {
            state = new Gold();
        }
        
    }
 
public String getState(){
    this.setState();
    
    Status = this.state.getStatus();
    
    return Status;
}

//
//public boolean redeemAndBuy(Book inBook) {
//        //bookPrice - points (100 points redeemed = 1 dollar) = remaining price 
//        //Remember to add statement to check and change status if needed
//        int BookPoints= inBook.getBookPoints();
//        int custPoints = this.getPoint();
//        
//        if(custPoints>=BookPoints){
//        custPoints-=BookPoints;
//        BookStore b = BookStore.getInstance();
//        b.deleteBooks(inBook.getBookTitle(),inBook.getBookPrice());
//        }
//       
//        
//        return true; // for no errors
//    }
}

