package RyeBookstoreApp;

import java.awt.Color;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.scene.layout.GridPane;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.geometry.Pos;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;

public class BookstoreApp extends Application {
    Button loginButton,managerBooksButton,managerCustomerButton,logoutButton,managerBooksAddButton,managerBooksDeleteButton,managerBackButton,managerCustomerBackButton,managerCustomerAddButton,managerCustomerDeleteButton,customerBuyButton,customerRedeemButton,customerLogoutButton,checkoutLogoutButton;
    Stage window;
    Scene owner,scenecustomer,loginScreen,bookScene,buyScreen;
    TableView<Books> booksTable,customerBookTable;
    TableView<Customer> ownerCustomerTable;     //table for the owner to see the customer info
    TextField bookNameInput,bookPriceInput,customerNameInput;
    PasswordField customerPassInput;
    ArrayList<Customer> CustomerList = new ArrayList<Customer>();
    ObservableList<Books> globalProduct = FXCollections.observableArrayList();
    public String customerLoginName = "";
    public double customerLoginPoints;
  
    public int lastBookIndex = -5;
    
    public static void main(String[] args) {
        launch(args);
        
    }
      
    @Override
    public void start(Stage primaryStage) {
        window = primaryStage;                                 // This initial application window would open (first scene)
        primaryStage.setTitle("Ryerson BookStore App");        //This will showcase the application title
             
        
         //In terms of creating our login screen:
        loginButton = new Button();                              // Initially started with creating a button
        loginButton.setText("Login");                            // Set text within the button itself
        GridPane.setConstraints(loginButton,1,4);                // Constraints are placed in order for positioning
        
        //Layout of how window appears to individuals is created below
        GridPane layout = new GridPane();                   // Layout on the Scene itself
        layout.setPadding(new Insets(10,10,10,10));         // Border around the screen of 10 pixels
        layout.setVgap(8);                                  // space between each of the columns
        layout.setHgap(5);                                  // space between each of the rows
        
        //Labels are created below
        Label ryersonWelcomeLabel = new Label ("Welcome to the Ryerson Bookstore ");  //Displays text on window (user can't interact with it)
        GridPane.setConstraints(ryersonWelcomeLabel,1,0);                             //Contraints are placed to position the text on the layout 
        
        Label usernameLabel = new Label("Username");              
        GridPane.setConstraints(usernameLabel,0,2);                
      
        Label passwordLabel = new Label("Password");
        GridPane.setConstraints(passwordLabel,0,3);
        
        //Label display = new Label ("Wrong Username or Password!");
        
        //Username field (this would be what the user will see when he tries to log in)
        TextField nameInput = new TextField();
        nameInput.setPromptText("Username");
        GridPane.setConstraints(nameInput,1,2);
        
        //Password Field (this would be what the user will see when he tries to log in)      
        PasswordField passInput = new PasswordField();
        passInput.setPromptText("Password"); 
        GridPane.setConstraints(passInput,1,3);    
        

  
                                       
        //Button functions         *will need to be modified/changed in order for customer info to be read off file
        loginButton.setOnAction(e -> {
           
            String username =  nameInput.getText();
             String pass= passInput.getText(); 
             ArrayList<String> listOfCustomers = ReadCustomers();
              //finding the current cutomer in the arraylist CustomerList
                                                                             
             if (username.equals("admin")){
                 if (pass.equals("admin")){
                     window.setScene(owner);
                 }
             } else {
                 for (int i = 0; i < listOfCustomers.size(); i++) {            //Would essentially go through the books arraylist
                     String[] arr = listOfCustomers.get(i).split(" ");         //Would split each line into words
                     String name = arr[0];
                     String password = arr[1];
                     
                     if (username.equals(name)) {
                         if (pass.equals(password)) {
                             customerLoginName = username; 
                             customerLoginPoints = Double.valueOf(arr[2]);
                             bookScene = initializeCustomerScene();
                             window.setScene(bookScene);
                             break;
                        }
                    }
                }
            }
             
     
        });
        
        layout.getChildren().addAll(loginButton,nameInput,passInput,usernameLabel,passwordLabel,ryersonWelcomeLabel);        
        loginScreen = new Scene(layout, 300, 200);
        
       
                                        
      //Buy screen
      
         checkoutLogoutButton = new Button();
         checkoutLogoutButton.setText("Logout");
         checkoutLogoutButton.setOnAction(e -> {
             changeCustomerPoints(customerLoginPoints);
             window.setScene(loginScreen);
         });
         GridPane.setConstraints(checkoutLogoutButton,3,2);
         
         Label totalCostLabel = new Label("The total cost is " + Buy());
         GridPane.setConstraints(totalCostLabel,3,0);
         Label totalPointLabel = new Label("Your total points is " + PointBuy());
         GridPane.setConstraints(totalPointLabel,3,1);
        
        GridPane layout3 = new GridPane();                   
        layout3.setPadding(new Insets(10,10,10,10));         
        layout3.setVgap(8);                                 
        layout3.setHgap(5);
        layout3.getChildren().addAll(totalCostLabel,totalPointLabel,checkoutLogoutButton);
        buyScreen = new Scene(layout3,200,100);
    
        
         //Owner-Books scene
         
        //Name column 
        TableColumn<Books,String> nameColumn = new TableColumn<>("Name");
        nameColumn.setMinWidth(250);
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

        //Price column 
        TableColumn<Books,Double> priceColumn = new TableColumn<>("Price");
        priceColumn.setMinWidth(250);
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        
        
        booksTable = new TableView<>();
        booksTable.setItems(getProduct());
        booksTable.getColumns().addAll(nameColumn,priceColumn);
       
         //Textfields 
       
        bookNameInput = new TextField();
        bookNameInput.setPromptText("Name");
        bookNameInput.setMinWidth(100);
        
        bookPriceInput = new TextField();
        bookPriceInput.setPromptText("Price");
        bookPriceInput.setMinWidth(100);
        
        managerBooksAddButton = new Button();
        managerBooksAddButton.setText("Add");
        managerBooksAddButton.setOnAction(e -> addButtonClicked());
        
        managerBooksDeleteButton = new Button();
        managerBooksDeleteButton.setText("Delete");
        managerBooksDeleteButton.setOnAction(e -> deleteButtonClicked());
        
        managerBackButton = new Button();
        managerBackButton.setText("Back");
        managerBackButton.setOnAction(e -> window.setScene(owner));
        
        HBox hBox = new HBox();
        hBox.setPadding(new Insets(10,10,10,10));
        hBox.setSpacing(15);  
        hBox.getChildren().addAll(bookNameInput,bookPriceInput,managerBooksAddButton,managerBooksDeleteButton,managerBackButton);
        
        VBox vBox = new VBox();
        vBox.getChildren().addAll(booksTable,hBox);
        Scene books;
        books = new Scene(vBox);
       
        //Customer Books screen---------------------------------------------------------------------------------------------
//        TableColumn<Books,String> naColumn = new TableColumn<>("Name");
//        naColumn.setMinWidth(250);
//        naColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
//
//        
//        TableColumn<Books,Double> priColumn = new TableColumn<>("Price");
//        priColumn.setMinWidth(250);
//        priColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
//        
//        
//        TableColumn<Books,CheckBox> selColumn = new TableColumn<>("Select");
//        selColumn.setMinWidth(100);
//        selColumn.setCellValueFactory(new PropertyValueFactory<>("select"));
//        
//        customerBookTable= new TableView<>();
//        customerBookTable.setItems(globalProduct);
//        customerBookTable.getColumns().addAll(naColumn,priColumn,selColumn);
//        
//        //Buy button
//        customerBuyButton = new Button();
//        customerBuyButton.setText("Buy");
//        customerBuyButton.setOnAction(e -> {
//            Buy();
//            buyScreen = initializeCustomerStartScene();
//            window.setScene(buyScreen);
//                });
//        //customerBuyButton.setOnAction(e -> window.setScene(buyScreen));
//        
//        customerRedeemButton = new Button();
//        customerRedeemButton.setText("Redeem points and Buy");
//        customerRedeemButton.setOnAction(e -> PointBuy());
//        customerRedeemButton.setOnAction(e -> window.setScene(buyScreen));
//        
//        customerLogoutButton = new Button();
//        customerLogoutButton.setText("Logout");
//        customerLogoutButton.setOnAction (e -> {
//            
//            changeCustomerPoints(customerLoginPoints);
//            window.setScene(loginScreen);
//        
//        });
//        //showing cutomer info in the label
////        //finding the current cutomer in the arraylist CustomerList
////        readCustomersFromFile();
////        Customer temp = new Customer();
////        for(Customer a: CustomerList){
////            if(a.getCusname().equals(customerLoginName)){ //a.getCusname()==customerLoginName
////                temp = a;
////            }            
////        }
//        
//        Label CustInfo = new Label();
//        CustInfo.setText("Customer name:"+customerLoginName+"  Points:"+ customerLoginPoints+
//                "   Status:"+ this.getCurrentCustomer(customerLoginName).getState());
//
//        HBox hhhBox = new HBox();
//        hhhBox.setPadding(new Insets(10,10,10,10));
//        hhhBox.setSpacing(30);  
//        hhhBox.getChildren().addAll(customerBuyButton,customerRedeemButton,customerLogoutButton);
//        
//        VBox vvvBox = new VBox();
//        vvvBox.getChildren().addAll(CustInfo,customerBookTable,hhhBox);
//        bookScene = new Scene(vvvBox);
         
        // Owner-Customer screen---------------------------------------------------------------------------------------------------------------------
        TableColumn<Customer,String> cusnameColumn = new TableColumn<>("Name");
        cusnameColumn.setMinWidth(250);
        cusnameColumn.setCellValueFactory(new PropertyValueFactory<>("cusname"));
         
        TableColumn<Customer,String> cuspassColumn = new TableColumn<>("Password");
        cuspassColumn.setMinWidth(150);
        cuspassColumn.setCellValueFactory(new PropertyValueFactory<>("cuspass"));
        
        TableColumn<Customer,Double> pointColumn = new TableColumn<>("Point");
        pointColumn.setMinWidth(130);
        pointColumn.setCellValueFactory(new PropertyValueFactory<>("point"));
      
        ownerCustomerTable = new TableView<>();
        ownerCustomerTable.setItems(getCustomer());
        ownerCustomerTable.getColumns().addAll(cusnameColumn,cuspassColumn,pointColumn);
       
        managerCustomerAddButton = new Button();
        managerCustomerAddButton.setText("Add");
        managerCustomerAddButton.setOnAction(e -> addButtonClickedCustomer());
        
        managerCustomerDeleteButton = new Button();
        managerCustomerDeleteButton.setText("Delete");
        managerCustomerDeleteButton.setOnAction(e -> deleteButtonClickedCustomer());
        
        managerCustomerBackButton = new Button();
        managerCustomerBackButton.setText("Back");
        managerCustomerBackButton.setOnAction(e -> window.setScene(owner));
        
        //Text fields
        customerNameInput = new TextField();
        customerNameInput.setPromptText("Name");
        customerNameInput.setMinWidth(150);
        
        customerPassInput = new PasswordField();
        customerPassInput.setPromptText("Password");
        customerPassInput.setMinWidth(150);
      
        HBox hhBox = new HBox();
        hhBox.setPadding(new Insets(10,10,10,10));
        hhBox.setSpacing(15);  
        hhBox.getChildren().addAll(customerNameInput,customerPassInput,managerCustomerAddButton,managerCustomerDeleteButton,managerCustomerBackButton);
        
        VBox vvBox = new VBox();
        vvBox.getChildren().addAll(ownerCustomerTable,hhBox);
        Scene customer;
        customer = new Scene(vvBox);
        
        //Owner main screen-------------------------------------------------------------------------------------------- 
        managerBooksButton = new Button();                             
        managerBooksButton.setText("Books");                    
        managerBooksButton.setOnAction(e ->window.setScene(books));
        GridPane.setConstraints(managerBooksButton,6,3);
        
        managerCustomerButton = new Button();
        managerCustomerButton.setText("Customer");
        managerCustomerButton.setOnAction (e -> window.setScene(customer));  
        GridPane.setConstraints(managerCustomerButton,6,5);
        
        logoutButton = new Button();
        logoutButton.setText("Logout");
        logoutButton.setOnAction(e -> window.setScene(loginScreen));
        GridPane.setConstraints(logoutButton,6,7);
        

        //Layout
        GridPane layout2 = new GridPane();                                     // containts are utilized to position the scene
        layout2.setPadding(new Insets(10,10,10,10));
        layout2.setVgap(8); 
        layout2.setHgap(20); 
        layout2.getChildren().addAll(managerBooksButton,managerCustomerButton,logoutButton);    // this would add button to scene
        owner = new Scene(layout2, 350, 200);                                // contraints are used to resize scene

       
        
         window.setScene(loginScreen);                // this would essentially load login scene
         window.show();     
        
 }//end of start

    private Scene initializeCustomerScene(){
       
         TableColumn<Books,String> naColumn = new TableColumn<>("Name");
        naColumn.setMinWidth(250);
        naColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

        
        TableColumn<Books,Double> priColumn = new TableColumn<>("Price");
        priColumn.setMinWidth(250);
        priColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        
        
        TableColumn<Books,CheckBox> selColumn = new TableColumn<>("Select");
        selColumn.setMinWidth(100);
        selColumn.setCellValueFactory(new PropertyValueFactory<>("select"));
        
        customerBookTable= new TableView<>();
        customerBookTable.setItems(globalProduct);
        customerBookTable.getColumns().addAll(naColumn,priColumn,selColumn);
        
        //Buy button
        customerBuyButton = new Button();
        customerBuyButton.setText("Buy");
        customerBuyButton.setOnAction(e -> {
            Buy();
            buyScreen = initializeCustomerStartScene();
            window.setScene(buyScreen);
                });
        //customerBuyButton.setOnAction(e -> window.setScene(buyScreen));
        
        customerRedeemButton = new Button();
        customerRedeemButton.setText("Redeem points and Buy");
        customerRedeemButton.setOnAction(e -> PointBuy());
        customerRedeemButton.setOnAction(e -> window.setScene(buyScreen));
        
        customerLogoutButton = new Button();
        customerLogoutButton.setText("Logout");
        customerLogoutButton.setOnAction (e -> {
            
            changeCustomerPoints(customerLoginPoints);
            window.setScene(loginScreen);
        
        });
        Label custInfo = new Label("Customer name: " + customerLoginName +"  Points: "+ customerLoginPoints+ "   Status: "+ this.getCurrentCustomer(customerLoginName).getState());
        HBox hhhBox = new HBox();
        hhhBox.setPadding(new Insets(10,10,10,10));
        hhhBox.setSpacing(30);  
        hhhBox.getChildren().addAll(customerBuyButton,customerRedeemButton,customerLogoutButton);
        
        VBox vvvBox = new VBox();
        vvvBox.getChildren().addAll(custInfo,customerBookTable,hhhBox);
        return new Scene (vvvBox);
    }
    private Scene initializeCustomerStartScene(){ 
        double cartTotal = 0;
        double totalPointsEarned = 0;
        for(int i=0; i < globalProduct.size(); i++){
            if(globalProduct.get(i).getSelect().isSelected()){
                cartTotal += globalProduct.get(i).getPrice();
            }
        }
        totalPointsEarned = cartTotal * 10;
        customerLoginPoints += ((int) totalPointsEarned);
        Text totalCost = new Text("Total Cart: " + cartTotal);
        Text points = new Text("Points earned: " + totalPointsEarned);
        
        
        Button checkOutLogoutBtn = new Button("Logout");
        checkOutLogoutBtn.setOnAction(e -> window.setScene(loginScreen));
        
        VBox checkoutLayout = new VBox(50, totalCost, points, checkOutLogoutBtn);
        checkoutLayout.setAlignment(Pos.CENTER);
        
        StackPane checkoutLayout1 = new StackPane(checkoutLayout);
        
        changeCustomerPoints(customerLoginPoints);
        deleteActionAfterBuy();
        
        return new Scene (checkoutLayout1, 200, 200);
    }
    //Contructed a method to initialize both the customer-cost scene and the customer-start scene
    public double Buy(){
        //System.out.println("Hello");
        double cartTotal = 0;
        double totalPointsEarned = 0;
        totalPointsEarned = cartTotal * 10;
        customerLoginPoints += ((int) totalPointsEarned);
        for(int i=0; i < globalProduct.size(); i++){
            if(globalProduct.get(i).getSelect().isSelected()){
                cartTotal += globalProduct.get(i).getPrice();
            }
        }
        System.out.println("Total cart: " + cartTotal);
        System.out.println("Point of the customer: " + customerLoginPoints);
        System.out.println("Total Points earned: " + totalPointsEarned);
        System.out.println("Total points of the customer after buy: " + customerLoginPoints);
        changeCustomerPoints(customerLoginPoints);
        //deleteActionAfterBuy();
        System.out.println(cartTotal);
        //Label buy1 = new Label("The total cost is " + Buy());
        
        // The variable initializing cartTotal returns
        // loginCustomer points would be updated here
        // The customers name is --->   customerLoginName
        // if total points are greater than 1000, you put Gold else Silver as in membership status
        // 
        
        return cartTotal;
    }
    
    public Customer getCurrentCustomer(String username){
    readCustomersFromFile();
      Customer temp = new Customer();
                                         for(Customer a: CustomerList){
                                            if(a.getCusname().equals(username)){ //a.getCusname()==customerLoginName
                                                temp = a;
                                            }            
                                        }
                                         return temp;
    }
    
    public double PointBuy(){
        System.out.println("Buy points clicked");
        System.out.println("Customer name: " + customerLoginName);
        
        double customerUsablePointsInCAD = customerLoginPoints / 100;
        int customerUsablePointsInCADInInteger = (int) customerUsablePointsInCAD;
        double cartTotal = 0;
        
        for(int i=0; i < globalProduct.size(); i++){
            if(globalProduct.get(i).getSelect().isSelected()){
                cartTotal += globalProduct.get(i).getPrice();
            }
        }
        
        System.out.println("Total: " + cartTotal);
        System.out.println("Point of the customer: " + customerLoginPoints);
        
        // customers points is -> customerLoginPoints
        // cart total returns from this function
        
        if(customerUsablePointsInCADInInteger >= cartTotal){
            System.out.println("Buyable amount in CAD with points: " + customerUsablePointsInCADInInteger);
            
            customerLoginPoints = customerLoginPoints - (cartTotal * 100);
            changeCustomerPoints(customerLoginPoints);
            System.out.println("Price after points redeemed: " + 0);
            System.out.println("New points of the customer: " + customerLoginPoints);
            //deleteActionAfterBuy();
            return 0;
        } else{
            System.out.println("Buyable amount with points: " + customerUsablePointsInCADInInteger);
            System.out.println("Price after points redeemed: " + (cartTotal - customerUsablePointsInCADInInteger));
            customerLoginPoints = customerLoginPoints - (customerUsablePointsInCADInInteger * 100);
            changeCustomerPoints(customerLoginPoints);
            System.out.println("New points of the customer: " + customerLoginPoints);
            //deleteActionAfterBuy();
            double pointbuy =(cartTotal - customerUsablePointsInCADInInteger);
            return pointbuy;
        }
    }//end of pointBuy
    
    private void readCustomersFromFile(){
        //this arraylist reads the text file Books.txt and adds the books as Bok objects into 
        //CustomerList arraylist
        //you can make it so that it takes the araylist as a parameter called CustomerList if you want to
        //Note: objects must be made into Books objects before being added to arraylist
        //the text file should contain this format: Username,password,points
      File books = new File("Customers.txt");
        try {
 
        Scanner myReader = new Scanner(books);
      
            while (myReader.hasNextLine()) 
            {
            String data = myReader.nextLine();
            System.out.println("datain file:"+ data+"\n");
            String dataArr[]= data.split(" ", 3);
            for (String a : dataArr)
                System.out.println(a);    
            Customer c= new Customer();
            c.setCusname(dataArr[0]);
            c.setCuspass(dataArr[1]);
            Double points = Double.parseDouble(dataArr[2]);
            c.setPoint(points);
            CustomerList.add(c);
            } //end of while
            
        myReader.close();
    } catch (FileNotFoundException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
    }//end of read
    
    public void changeCustomerPoints(double pointsToChange){
        String changedArray = "";
        ArrayList<String> listOfCustomers = ReadCustomers();                //Reads the Books.txt 
        for(int i = 0; i < listOfCustomers.size(); i++){                //Goes through the whole list and finds which book you want to delete in the file
            String[] arr = listOfCustomers.get(i).split(" ");
            
            if(customerLoginName.equals(arr[0])){
                String pointsInString = "" + pointsToChange;
                arr[2] = pointsInString;
                changedArray = arr[0];
                for(int j = 1; j < arr.length; j++){
                    changedArray += " " + arr[j];
                }
                listOfCustomers.set(i, changedArray);
            } 
        }
        
        FileWriter writer = null;                                   
        try {
            writer = new FileWriter("Customers.txt");                   //In the next 15 lines deletes everything in the Customers.txt file
        } catch (IOException ex) {
            System.out.println("Couldn't create Books2");;
        }
            
        try {
            writer.write("");
        } catch (IOException ex) {
            System.out.println("couldn't delete customers");;
        }
        try {
            writer.close();
        } catch (IOException ex) {
            System.out.println("Couldn't close customers");;
        }

        try {                                                       //Rewrites the list to th file
            writer = new FileWriter("Customers.txt");
        } catch (IOException ex) {
            System.out.println("Couldn't create Customers");;
        }
        try {
            if(listOfCustomers.size() > 0)
                writer.write("" + listOfCustomers.get(0));
        } catch (IOException ex) {
            System.out.println("IOException");
        }
        for(int i = 1; i < listOfCustomers.size(); i++) {
            try {
                writer.write("\n" + listOfCustomers.get(i));
            } catch (IOException ex) {
                System.out.println("IOException");
            }
        }
        try {
            writer.close();
        } catch (IOException ex) {
            System.out.println("Couldn't close books");;
        }
    }
    
    
    public static ArrayList<String> ReadCustomers(){
        ArrayList<String> listOfCustomers = new ArrayList<>();
        BufferedReader bufReader = null; 
        try {
            bufReader = new BufferedReader(new FileReader("Customers.txt"));
        } catch (FileNotFoundException ex) {
            System.out.println("Problem with BufferReader");
        }
        
        String line = null; 
        try {
            line = bufReader.readLine();
        } catch (IOException ex) {
            System.out.println("Problem with readLine");
        }
        while (line != null) { 
            listOfCustomers.add(line); 
            try { 
                line = bufReader.readLine();
            } catch (IOException ex) {
                System.out.println("Problem with bufReader");
            }
        } 
        try { 
            bufReader.close();
        } catch (IOException ex) {
            System.out.println("Books not closed");
        }
        return listOfCustomers;
    }
    
    public static ArrayList<String> ReadBooks(){
        ArrayList<String> listOfBooks = new ArrayList<>();
        BufferedReader bufReader = null; 
        try {
            bufReader = new BufferedReader(new FileReader("Books.txt"));
        } catch (FileNotFoundException ex) {
            System.out.println("Problem with BufferReader");
        }
        
        String line = null; 
        try {
            line = bufReader.readLine();
        } catch (IOException ex) {
            System.out.println("Problem with readLine");
        }
        while (line != null) { 
            listOfBooks.add(line); 
            try { 
                line = bufReader.readLine();
            } catch (IOException ex) {
                System.out.println("Problem with bufReader");
            }
        } 
        try { 
            bufReader.close();
        } catch (IOException ex) {
            System.out.println("Books not closed");
        }
        return listOfBooks;
    }
    
    public static void SaveCustomers(String thing){         //This function adds the books created to the Books.txt file
        
        FileOutputStream fos = null;

        try {
            fos = new FileOutputStream("Customers.txt", true);          //Open the file
            
            byte[] s_array = thing.getBytes();                      //Turn the string into bytes
            fos.write(s_array);                                     //Write the bytes

        } catch (FileNotFoundException ex) {                        //Throws file not found exception
            System.out.println("Customers not found");
        } catch (IOException ex) {
            System.out.println("IOException on SaveBooks");         //Throws IO exception
        }
        finally{
            try {
                fos.close();                                        //Close the file
            } catch (IOException ex) {                              //Throws couldn't close file exception
                System.out.println("Customers not closed");

            }
        }
    }
    
    
    public static void SaveBooks(String thing){         //This function adds the books created to the Books.txt file
        
        FileOutputStream fos = null;

        try {
            fos = new FileOutputStream("Books.txt", true);          //Open the file
            
            byte[] s_array = thing.getBytes();                      //Turn the string into bytes
            fos.write(s_array);                                     //Write the bytes

        } catch (FileNotFoundException ex) {                        //Throws file not found exception
            System.out.println("Books not found");
        } catch (IOException ex) {
            System.out.println("IOException on SaveBooks");         //Throws IO exception
        }
        finally{
            try {
                fos.close();                                        //Close the file
            } catch (IOException ex) {                              //Throws couldn't close file exception
                System.out.println("Books not closed");

            }
        }
    }
    
            ObservableList<Customer> customers = FXCollections.<Customer>observableArrayList();
    public ObservableList<Customer> getCustomer(){

        ArrayList<String> listOfCustomers = ReadCustomers();
        
        for(int i = 0; i < listOfCustomers.size(); i++){                //Goes through the books arraylist
            String[] arr = listOfCustomers.get(i).split(" ");        //Splits each line into words
            String name = "";
            String password = arr[arr.length-2];
            double points = Double.valueOf(arr[arr.length-1]);         //Last word is the price
            for(int j = 0; j < arr.length - 2; j++){                
                name += arr[j] + " ";                               //Add all the words except the price into a single string
            }
            customers.add(new Customer(name,password,points));                  //Creates a new object from the read book
        }

        return customers; 
    }

    public ObservableList<Books> getProduct(){                                     // can be used to read from a file
        ObservableList<Books> products = FXCollections.observableArrayList(); 
        ArrayList<String> listOfBooks = ReadBooks();                //Creates an Arraylist of the books in the Books.txt
        globalProduct.clear();
        for(int i = 0; i < listOfBooks.size(); i++){                //Goes through the books arraylist
            String[] arr = listOfBooks.get(i).split(" ");        //Splits each line into words
            int id = Integer.valueOf(arr[0]);
            String name = "";
            double price = Double.valueOf(arr[arr.length-1]);         //Last word is the price
            for(int j = 1; j < arr.length - 1; j++){                
                name += arr[j] + " ";                               //Add all the words except the price into a single string
            }
            products.add(new Books(id,name,price));                  //Creates a new object from the read book
            
        }
        if(products.size() > 0)
            lastBookIndex = products.get(products.size()-1).getId();
        else
            lastBookIndex = 0;
        
        globalProduct = products;
        return products;
     }
     
    public void addButtonClickedCustomer (){                    // To add a customer object
     Customer customer = new Customer();
     customer.setCusname(customerNameInput.getText());
     customer.setCuspass(customerPassInput.getText());

     ownerCustomerTable.getItems().add(customer);
     String prefix = globalProduct.size() > 0 ? "\n" : "";
     String customerToSave = prefix + customerNameInput.getText() + " " + customerPassInput.getText() + " 0";     //Makes a whole line of the name of the book and its price
     SaveCustomers(customerToSave);                                    //Sends the created line to SaveBooks function 
     
     customerNameInput.clear();
     customerPassInput.clear();
    }

    public void deleteButtonClickedCustomer () {                 // To delete a customer from the object
      ObservableList<Customer> cusSelected, allCustomer;
      allCustomer = ownerCustomerTable.getItems();
      cusSelected = ownerCustomerTable.getSelectionModel().getSelectedItems();

      int wantToDelete= -9;
      ArrayList<String> lisOfCustomers = ReadCustomers();                //Reads the Books.txt 
      for(int i = 0; i < lisOfCustomers.size(); i++){                //Goes through the whole list and finds which book you want to delete in the file
          String[] arr = lisOfCustomers.get(i).split(" ");
          String name = "";
          String password = arr[arr.length-2];
          double points = Double.valueOf(arr[arr.length-1]);

          for(int j = 0; j < arr.length - 2; j++){
              name += arr[j] + " ";
          }
          if(name.equals(cusSelected.get(0).getCusname())){
              wantToDelete = i;
          }
      }
      if(wantToDelete != -9){    
          lisOfCustomers.remove(wantToDelete);                           //Deletes the book from the list
      } else{
          lisOfCustomers.remove(lisOfCustomers.size()-1);
      }   
      FileWriter writer = null;                                   
      try {
          writer = new FileWriter("Customers.txt");                   //In the next 15 lines deletes everything in the Books.txt file
      } catch (IOException ex) {
          System.out.println("Couldn't create Customers");;
      }

      try {
          writer.write("");
      } catch (IOException ex) {
          System.out.println("couldn't delete Customers");;
      }
      try {
          writer.close();
      } catch (IOException ex) {
          System.out.println("Couldn't close Customers.txt");;
      }

      try {                                                       //Rewrites the list to th file
          writer = new FileWriter("Customers.txt");
      } catch (IOException ex) {
          System.out.println("Couldn't create Customers");;
      }
      try {
          writer.write("" + lisOfCustomers.get(0));
      } catch (IOException ex) {
          System.out.println("IOException");
      }
      for(int i = 1; i < lisOfCustomers.size(); i++) {
          try {
              writer.write("\n" + lisOfCustomers.get(i));
          } catch (IOException ex) {
              System.out.println("IOException");
          }
      }
      try {
          writer.close();
      } catch (IOException ex) {
          System.out.println("Couldn't close Customers.txt");;
      }

      cusSelected.forEach(allCustomer::remove);
    }
     
    public void addButtonClicked(){
         Books products = new Books();
         products.setId(lastBookIndex += 1);
         products.setName(bookNameInput.getText());
         products.setPrice(Double.parseDouble(bookPriceInput.getText()));
         
         String prefix = globalProduct.size() > 0 ? "\n" : "";
         globalProduct.add(products);
         String bookToSave = prefix + (lastBookIndex) + " " +  bookNameInput.getText() + " " + bookPriceInput.getText();     //Makes a whole line of the name of the book and its price
         SaveBooks(bookToSave);                                    //Sends the created line to SaveBooks function
         
         bookNameInput.clear();
         bookPriceInput.clear();
     }
    
    public void deleteActionAfterBuy(){
        ObservableList<Books> remainingBooks = globalProduct;
        for(int i = globalProduct.size() - 1 ; i >= 0 ; i--){
            if(globalProduct.get(i).getSelect().isSelected()){
                deleteProductFromFile(globalProduct.get(i).getId());
                remainingBooks.remove(i);
            }
        }
        globalProduct = remainingBooks;
    }
    
    public void deleteProductFromFile(int id){
        int wantToDelete = -80;
        ArrayList<String> listOfBooks = ReadBooks();                //Reads the Books.txt 
        for(int i = 0; i < listOfBooks.size(); i++){                //Goes through the whole list and finds which book you want to delete in the file
            String[] arr = listOfBooks.get(i).split(" ");
            
            if(id == Integer.valueOf(arr[0])){
                wantToDelete = i;
            }
            
        }
        if(wantToDelete != -80){    
            listOfBooks.remove(wantToDelete);                           //Deletes the book from the list
        }   
        
        FileWriter writer = null;                                   
        try {
            writer = new FileWriter("Books.txt");                   //In the next 15 lines deletes everything in the Books.txt file
        } catch (IOException ex) {
            System.out.println("Couldn't create Books2");;
        }
            
        try {
            writer.write("");
        } catch (IOException ex) {
            System.out.println("couldn't delete books");;
        }
        try {
            writer.close();
        } catch (IOException ex) {
            System.out.println("Couldn't close books");;
        }

        try {                                                       //Rewrites the list to th file
            writer = new FileWriter("Books.txt");
        } catch (IOException ex) {
            System.out.println("Couldn't create Books");;
        }
        try {
            if(listOfBooks.size() > 0)
                writer.write("" + listOfBooks.get(0));
        } catch (IOException ex) {
            System.out.println("IOException");
        }
        for(int i = 1; i < listOfBooks.size(); i++) {
            try {
                writer.write("\n" + listOfBooks.get(i));
            } catch (IOException ex) {
                System.out.println("IOException");
            }
        }
        try {
            writer.close();
        } catch (IOException ex) {
            System.out.println("Couldn't close books");;
        }
    }
    
    public void deleteButtonClicked(){
        ObservableList<Books> productSelected,allProducts; 
        allProducts = booksTable.getItems();
        productSelected = booksTable.getSelectionModel().getSelectedItems();
        
        int wantToDelete = -80;
        ArrayList<String> listOfBooks = ReadBooks();                //Reads the Books.txt 
        for(int i = 0; i < listOfBooks.size(); i++){                //Goes through the whole list and finds which book you want to delete in the file
            String[] arr = listOfBooks.get(i).split(" ");
            String name = "";
           
            for(int j = 1; j < arr.length - 1; j++){
                name += arr[j] + " ";
            }
            if(name.contains(productSelected.get(0).getName())){
                wantToDelete = i;
            }
        }
        if(wantToDelete != -80){    
            listOfBooks.remove(wantToDelete);                           //Deletes the book from the list
        }   
        
        FileWriter writer = null;                                   
        try {
            writer = new FileWriter("Books.txt");                   //In the next 15 lines deletes everything in the Books.txt file
        } catch (IOException ex) {
            System.out.println("Couldn't create Books2");;
        }
            
        try {
            writer.write("");
        } catch (IOException ex) {
            System.out.println("couldn't delete books");;
        }
        try {
            writer.close();
        } catch (IOException ex) {
            System.out.println("Couldn't close books");;
        }

        try {                                                       //Rewrites the list to th file
            writer = new FileWriter("Books.txt");
        } catch (IOException ex) {
            System.out.println("Couldn't create Books");;
        }
        try {
            if(listOfBooks.size() > 0){
                writer.write("" + listOfBooks.get(0));
            }
        } catch (IOException ex) {
            System.out.println("IOException");
        }
        for(int i = 1; i < listOfBooks.size(); i++) {
            try {
                writer.write("\n" + listOfBooks.get(i));
            } catch (IOException ex) {
                System.out.println("IOException");
            }
        }
        try {
            writer.close();
        } catch (IOException ex) {
            System.out.println("Couldn't close books");;
        }
        
        productSelected.forEach(allProducts::remove);
     }
 }